"""
config.py - Configuration & Constants
"""

import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# ============== API KEYS ==============

GEMINI_API_KEY = os.getenv('GEMINI_API_KEY', '')

if not GEMINI_API_KEY:
    print("⚠️  WARNING: GEMINI_API_KEY not set in environment!")
    print("   Please set it in .env file or as environment variable")

# ============== MODEL NAMES ==============

class Models:
    """Gemini model names"""
    FLASH = "gemini-2.0-flash-exp"  # Fast text generation
    PRO = "gemini-2.5-pro"  # Advanced reasoning
    FLASH_IMAGE = "gemini-2.0-flash-exp"  # Image generation (using Flash model)


# ============== GENERATION DEFAULTS ==============

class Defaults:
    """Default generation parameters"""
    TEMPERATURE_ANALYSIS = 0.3
    TEMPERATURE_TRANSLATION = 0.1
    TEMPERATURE_GENERATION = 0.7
    MAX_OUTPUT_TOKENS = 8192


# ============== SERVER CONFIG ==============

class ServerConfig:
    """Flask server configuration"""
    HOST = '0.0.0.0'
    PORT = int(os.getenv('PORT', 5001))
    DEBUG = os.getenv('DEBUG', 'True').lower() == 'true'
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB


# ============== LOGGING ==============

import logging

LOG_LEVEL = logging.DEBUG if ServerConfig.DEBUG else logging.INFO
LOG_FORMAT = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'


# ============== ASPECT RATIOS ==============

SUPPORTED_ASPECT_RATIOS = {
    "16:9": (1920, 1080),
    "4:3": (1600, 1200),
    "1:1": (1024, 1024),
    "9:16": (1080, 1920),  # Vertical
    "21:9": (2560, 1080)   # Ultrawide
}


# ============== CAMERA VIEWPOINTS ==============

CAMERA_VIEWPOINTS = {
    "main_facade": {
        "name": "Main Façade",
        "prompt_suffix": "Direct front view of main facade, straight-on architectural photography perspective"
    },
    "side_view": {
        "name": "Side View",
        "prompt_suffix": "Side elevation view showing building profile and depth"
    },
    "aerial_view": {
        "name": "Aerial View",
        "prompt_suffix": "Elevated aerial perspective, 30-45 degree angle from above"
    },
    "street_level": {
        "name": "Street Level",
        "prompt_suffix": "Eye-level street photography, human perspective from sidewalk"
    },
    "corner_view": {
        "name": "Corner View",
        "prompt_suffix": "3/4 view from corner showing two facades, dynamic composition"
    }
}


# ============== NEGATIVE PROMPT ITEMS ==============

DEFAULT_NEGATIVE_ITEMS = [
    "text",
    "watermarks",
    "logos",
    "signatures",
    "distorted proportions",
    "unrealistic colors",
    "blurry details",
    "artifacts",
    "duplicate elements"
]


# ============== ANALYSIS PROMPT ==============

ANALYSIS_SYSTEM_PROMPT_VI = """
**NHIỆM VỤ**: Phân tích bản vẽ kiến trúc và trả về mô tả tiếng Việt chi tiết

**OUTPUT FORMAT** (JSON):
{
    "building_type": "Loại công trình (Nhà phố, biệt thự, ...)",
    "facade_style": "Phong cách mặt tiền (Hiện đại, tối giản, ...)",
    "structure_description": "Mô tả cấu trúc tổng quan",
    "materials_detected": [
        {
            "element": "Phần tử (Tường, mái, cửa, ...)",
            "material_guess": "Chất liệu dự đoán",
            "notes": "Ghi chú"
        }
    ],
    "special_features": ["Đặc điểm nổi bật 1", "Đặc điểm 2", ...],
    "suggested_lighting": "Gợi ý ánh sáng phù hợp",
    "suggested_environment": "Bối cảnh phù hợp (cây xanh, bầu trời, ...)"
}

**QUY TẮC**:
1. Phân tích kỹ lưỡng các tỷ lệ, đường nét trong bản vẽ
2. Nhận diện các yếu tố kiến trúc: cửa, cửa sổ, ban công, mái, ...
3. Đoán chất liệu dựa trên phong cách và hình thức
4. Đưa ra gợi ý về ánh sáng và bối cảnh phù hợp
5. Chú trọng vào các đặc điểm độc đáo của thiết kế

Trả về JSON hợp lệ, không có markdown.
"""


# ============== TRANSLATION PROMPT ==============

RESTRUCTURE_AND_TRANSLATE_PROMPT = """
**NHIỆM VỤ**: Dịch và cấu trúc lại dữ liệu form tiếng Việt sang tiếng Anh

**INPUT**: JSON với dữ liệu form tiếng Việt (có thể không cấu trúc)

**OUTPUT FORMAT** (JSON):
{
    "building_core": {
        "type": "Building type in English",
        "style_primary": "Primary architectural style",
        "style_secondary": "Secondary style (if any)"
    },
    "critical_geometry": {
        "overall_form": "Overall building shape",
        "proportions": "Proportions description",
        "key_elements": ["Element 1", "Element 2", ...]
    },
    "materials_hierarchy": [
        {
            "priority": 1,
            "element": "Building element",
            "material": "Material name",
            "color": "Color description",
            "texture": "Texture notes"
        }
    ],
    "environment_context": {
        "lighting": "Lighting conditions",
        "time": "Time of day",
        "weather": "Weather conditions",
        "surroundings": "Environmental context"
    },
    "technical_photo_specs": {
        "camera": "Camera type description",
        "lens": "Lens specifications",
        "angle": "Camera angle",
        "mood": "Desired mood"
    }
}

**QUY TẮC**:
1. Dịch TẤT CẢ nội dung sang tiếng Anh chất lượng cao
2. Sắp xếp materials theo thứ tự ưu tiên (priority: 1, 2, 3, ...)
3. Giữ nguyên ý nghĩa và chi tiết từ input
4. Mở rộng các mô tả ngắn gọn thành mô tả rõ ràng hơn
5. Chuẩn hóa thuật ngữ kiến trúc

Trả về JSON hợp lệ, không có markdown.
"""


# ============== IMAGE PROCESSING ==============

class ImageConfig:
    """Image processing configuration"""
    MAX_DIMENSION = 2048
    SKETCH_ENHANCEMENT_THRESHOLD = 127
    EDGE_DETECTION_THRESHOLD = (50, 150)
    MIN_SKETCH_INTENSITY = 30
