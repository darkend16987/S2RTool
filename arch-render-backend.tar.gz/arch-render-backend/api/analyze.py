"""
api/analyze.py - Sketch Analysis Endpoint
"""

from flask import Blueprint, request, jsonify

from core.image_processor import ImageProcessor
from core.prompt_builder import PromptBuilder
from core.gemini_client import GeminiClient
from config import Models

analyze_bp = Blueprint('analyze', __name__)

processor = ImageProcessor()
prompt_builder = PromptBuilder()
gemini = GeminiClient()


@analyze_bp.route('/analyze-sketch', methods=['POST'])
def analyze_sketch():
    """
    Analyze sketch and return Vietnamese description
    
    Request:
    {
        "image_base64": "..."
    }
    
    Response:
    {
        "building_type": "...",
        "facade_style": "...",
        "sketch_detail_level": "...",
        ...
    }
    """
    try:
        data = request.json
        
        if 'image_base64' not in data:
            return jsonify({"error": "Missing image_base64"}), 400
        
        # Process image
        pil_image, _ = processor.process_base64_image(data['image_base64'])
        if not pil_image:
            return jsonify({"error": "Invalid image"}), 400
        
        # Detect sketch type
        sketch_info = processor.detect_sketch_type(pil_image)
        
        # Resize if needed
        pil_image = processor.resize_image(pil_image, max_size=1024)
        
        # Analyze with Gemini
        analysis_prompt = prompt_builder.build_analysis_prompt()
        
        analysis_result = gemini.generate_content_json(
            prompt_parts=[analysis_prompt, pil_image],
            model_name=Models.PRO,
            temperature=0.3
        )
        
        # Add sketch detection info
        analysis_result['sketch_detail_level'] = sketch_info.detail_level
        analysis_result['is_colored'] = sketch_info.is_colored
        analysis_result['sketch_type'] = sketch_info.sketch_type
        
        return jsonify(analysis_result)
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500
