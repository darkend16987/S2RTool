"""
api/render.py - Main Render Endpoint
"""

from flask import Blueprint, request, jsonify
import base64
import io

from core.image_processor import ImageProcessor
from core.prompt_builder import PromptBuilder
from core.gemini_client import GeminiClient

render_bp = Blueprint('render', __name__)

processor = ImageProcessor()
prompt_builder = PromptBuilder()
gemini = GeminiClient()


@render_bp.route('/render', methods=['POST'])
def render_image():
    """
    Main render endpoint
    
    Request:
    {
        "image_base64": "...",
        "translated_data_en": {...},
        "aspect_ratio": "16:9",
        "viewpoint": "main_facade",
        "reference_image_base64": "..." (optional)
    }
    
    Response:
    {
        "generated_image_base64": "...",
        "mime_type": "image/png",
        "aspect_ratio": "16:9",
        "viewpoint": "main_facade"
    }
    """
    try:
        data = request.json
        
        # Validate required fields
        required = ['image_base64', 'translated_data_en', 'aspect_ratio']
        if not all(k in data for k in required):
            return jsonify({"error": f"Missing required fields: {required}"}), 400
        
        # Process sketch image
        sketch_pil, _ = processor.process_base64_image(data['image_base64'])
        if not sketch_pil:
            return jsonify({"error": "Invalid sketch image"}), 400
        
        # Detect and preprocess
        sketch_info = processor.detect_sketch_type(sketch_pil)
        preprocessed = processor.preprocess_sketch(
            sketch_pil,
            target_aspect_ratio=data['aspect_ratio'],
            sketch_info=sketch_info
        )
        
        # Process reference image (optional)
        reference_pil = None
        if 'reference_image_base64' in data:
            reference_pil, _ = processor.process_base64_image(data['reference_image_base64'])
        
        # Build prompt
        translated_data = data['translated_data_en']
        viewpoint = data.get('viewpoint', 'main_facade')
        
        prompt, _ = prompt_builder.build_render_prompt(
            translated_data_en=translated_data,
            viewpoint=viewpoint,
            has_reference=(reference_pil is not None)
        )
        
        # Generate image
        generated_pil = gemini.generate_image(
            prompt=prompt,
            source_image=preprocessed,
            reference_image=reference_pil
        )
        
        if not generated_pil:
            return jsonify({"error": "Image generation failed"}), 500
        
        # Convert to base64
        img_byte_arr = io.BytesIO()
        generated_pil.save(img_byte_arr, format='PNG')
        img_base64 = base64.b64encode(img_byte_arr.getvalue()).decode('utf-8')
        
        return jsonify({
            "generated_image_base64": img_base64,
            "mime_type": "image/png",
            "aspect_ratio": data['aspect_ratio'],
            "viewpoint": viewpoint,
            "sketch_type": sketch_info.sketch_type
        })
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500
