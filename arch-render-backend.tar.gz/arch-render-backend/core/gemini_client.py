"""
core/gemini_client.py - Gemini API Client Wrapper
"""

import json
import re
from typing import List, Optional, Union, Dict
from google import generativeai as genai
from google.generativeai import types
from PIL import Image

from config import GEMINI_API_KEY, Models, Defaults


class GeminiClient:
    """Wrapper for Gemini API operations"""
    
    def __init__(self, api_key: Optional[str] = None):
        """
        Initialize Gemini client
        
        Args:
            api_key: Gemini API key (uses config if None)
        """
        self.api_key = api_key or GEMINI_API_KEY
        genai.configure(api_key=self.api_key)
    
    def generate_content_json(
        self,
        prompt_parts: Union[str, List],
        model_name: str = Models.FLASH,
        temperature: float = Defaults.TEMPERATURE_ANALYSIS
    ) -> Dict:
        """
        Generate content and parse as JSON
        
        Args:
            prompt_parts: String prompt or list of [text, image, ...]
            model_name: Model to use
            temperature: Generation temperature
        
        Returns:
            Parsed JSON dict
        
        Raises:
            ValueError: If JSON parsing fails
        """
        model = genai.GenerativeModel(model_name)
        
        # Ensure prompt_parts is a list
        if isinstance(prompt_parts, str):
            prompt_parts = [prompt_parts]
        
        # Generate
        response = model.generate_content(
            prompt_parts,
            generation_config=types.GenerationConfig(
                temperature=temperature,
                response_mime_type="application/json"
            )
        )
        
        response_text = response.text.strip()
        
        # Clean markdown code blocks
        if response_text.startswith('```'):
            response_text = re.sub(r'^```(?:json)?\s*', '', response_text)
            response_text = re.sub(r'\s*```$', '', response_text)
        
        # Parse JSON
        try:
            return json.loads(response_text)
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON from Gemini: {str(e)}\nResponse: {response_text[:500]}")
    
    def generate_image(
        self,
        prompt: str,
        source_image: Optional[Image.Image] = None,
        reference_image: Optional[Image.Image] = None,
        model_name: str = Models.FLASH_IMAGE,
        temperature: float = Defaults.TEMPERATURE_GENERATION
    ) -> Optional[Image.Image]:
        """
        Generate image using Gemini Flash Image
        
        Args:
            prompt: Text prompt
            source_image: Source sketch image (optional)
            reference_image: Style reference (optional)
            model_name: Model to use
            temperature: Generation temperature
        
        Returns:
            Generated PIL Image or None
        """
        model = genai.GenerativeModel(model_name)
        
        # Build parts list
        parts = []
        
        if source_image:
            parts.append(source_image)
        
        if reference_image:
            parts.append(reference_image)
        
        parts.append(prompt)
        
        # Generate
        try:
            response = model.generate_content(
                parts,
                generation_config=types.GenerationConfig(
                    temperature=temperature,
                    response_modalities=['IMAGE']
                )
            )
            
            # Extract image from response
            for part in response.candidates[0].content.parts:
                if part.inline_data:
                    import base64
                    import io
                    image_bytes = base64.b64decode(part.inline_data.data)
                    return Image.open(io.BytesIO(image_bytes))
            
            return None
            
        except Exception as e:
            print(f"Image generation failed: {e}")
            return None
    
    def generate_with_inpaint(
        self,
        original: Image.Image,
        mask: Image.Image,
        prompt: str,
        reference: Optional[Image.Image] = None
    ) -> Optional[Image.Image]:
        """
        Generate with inpainting (using prompt-based approach)
        
        Args:
            original: Original image
            mask: Binary mask (255=edit, 0=preserve)
            prompt: Inpainting instruction
            reference: Optional style reference
        
        Returns:
            Edited image or None
        """
        parts = [original, mask]
        
        if reference:
            parts.append(reference)
        
        parts.append(prompt)
        
        return self.generate_image(
            prompt="",  # Prompt already in parts
            source_image=None,
            reference_image=None,
            model_name=Models.FLASH_IMAGE
        )
