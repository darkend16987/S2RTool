"""
app.py - Main Flask Application
"""

import os
from flask import Flask, jsonify
from flask_cors import CORS

from config import ServerConfig
from api.render import render_bp
from api.translate import translate_bp
from api.analyze import analyze_bp
from api.references import references_bp
from api.inpaint import inpaint_bp


def create_app():
    """Application factory"""
    app = Flask(__name__)
    
    # Configuration
    app.config['MAX_CONTENT_LENGTH'] = ServerConfig.MAX_CONTENT_LENGTH
    
    # CORS
    CORS(app)
    
    # Register blueprints (All priorities)
    app.register_blueprint(render_bp, url_prefix='/api')
    app.register_blueprint(translate_bp, url_prefix='/api')
    app.register_blueprint(analyze_bp, url_prefix='/api')
    app.register_blueprint(references_bp, url_prefix='/api')
    app.register_blueprint(inpaint_bp, url_prefix='/api')
    
    # Health check
    @app.route('/health', methods=['GET'])
    def health_check():
        return jsonify({
            "status": "healthy",
            "features": [
                "sketch_analysis",
                "vi_to_en_translation",
                "multi_viewpoint_rendering",
                "reference_library",
                "inpainting"
            ],
            "version": "1.0 - Full Feature Set"
        })
    
    # Error handlers
    @app.errorhandler(413)
    def request_entity_too_large(error):
        return jsonify({"error": "File too large (max 16MB)"}), 413
    
    @app.errorhandler(500)
    def internal_error(error):
        return jsonify({"error": "Internal server error"}), 500
    
    return app


if __name__ == '__main__':
    app = create_app()
    app.run(
        host=ServerConfig.HOST,
        port=ServerConfig.PORT,
        debug=ServerConfig.DEBUG
    )
